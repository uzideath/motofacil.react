"use client"

import { useCallback, useEffect, useState, useMemo } from "react"
import { DEFAULT_ITEMS_PER_PAGE } from "../constants"
import { PaymentMethod, SelectedTransaction, SortField, Transaction, TransactionFiltersState } from "../constants/types"
import { calculatePagination, calculateTransactionSummary, filterAndSortTransactions } from "../utils/filters"
import { fetchAvailableTransactions } from "../services"
import { formatProviderName } from "../utils/formatters"

interface UseTransactionsProps {
    token: string
    onSelect?: (transactions: SelectedTransaction[]) => void
    itemsPerPage?: number
}

export const useTransactions = ({ token, onSelect, itemsPerPage = DEFAULT_ITEMS_PER_PAGE }: UseTransactionsProps) => {
    // State
    const [transactions, setTransactions] = useState<Transaction[]>([])
    const [loading, setLoading] = useState(true)
    const [refreshing, setRefreshing] = useState(false)
    const [globalSelectedIds, setGlobalSelectedIds] = useState<Set<string>>(new Set()) // Global selection across all pages
    const [currentPage, setCurrentPage] = useState(1)

    // Provider mismatch dialog state
    const [showProviderMismatchDialog, setShowProviderMismatchDialog] = useState(false)
    const [currentProviderName, setCurrentProviderName] = useState<string | undefined>(undefined)
    const [attemptedProviderName, setAttemptedProviderName] = useState<string | undefined>(undefined)

    // Filters state
    const [filters, setFilters] = useState<TransactionFiltersState>({
        searchTerm: "",
        typeFilter: "all",
        providerFilter: "all",
        sortField: null,
        sortDirection: "asc",
    })

    // Derived state
    const filteredTransactions = filterAndSortTransactions(transactions, filters)
    const { totalIncome, totalExpense, netAmount } = calculateTransactionSummary(filteredTransactions)
    const { totalPages, indexOfFirstItem, indexOfLastItem } = calculatePagination(
        filteredTransactions.length,
        currentPage,
        itemsPerPage,
    )
    const currentItems = filteredTransactions.slice(indexOfFirstItem, indexOfLastItem)

    // Get selected IDs for current page only (for UI display)
    const currentPageSelectedIds = useMemo(() => {
        return currentItems
            .filter((transaction) => globalSelectedIds.has(transaction.id))
            .map((transaction) => transaction.id)
    }, [currentItems, globalSelectedIds])

    // Calculate totals for selected transactions across all pages
    const selectedTransactionsSummary = useMemo(() => {
        const selectedTransactions = transactions.filter((transaction) => globalSelectedIds.has(transaction.id))

        const totalIncome = selectedTransactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)
        const totalExpense = selectedTransactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)

        return {
            selectedTransactions,
            totalIncome,
            totalExpense,
            netAmount: totalIncome - totalExpense,
            count: selectedTransactions.length,
        }
    }, [transactions, globalSelectedIds])

    const hasActiveFilters =
        filters.searchTerm !== "" ||
        filters.typeFilter !== "all" ||
        filters.providerFilter !== "all" ||
        filters.sortField !== null

    // Helper function to convert string to PaymentMethod enum
    const getPaymentMethod = (paymentMethod: string | PaymentMethod): PaymentMethod => {
        if (typeof paymentMethod === "string") {
            // Try to match the string to a PaymentMethod enum value
            const upperMethod = paymentMethod.toUpperCase()
            if (Object.values(PaymentMethod).includes(upperMethod as PaymentMethod)) {
                return upperMethod as PaymentMethod
            }
            // Default fallback
            return PaymentMethod.CASH
        }
        return paymentMethod
    }

    // Fetch transactions
    const fetchTransactions = useCallback(async () => {
        try {
            setLoading(true)
            setRefreshing(true)
            const data = await fetchAvailableTransactions(token)
            setTransactions(data)
        } catch (error) {
            console.error("Error loading transactions:", error)
        } finally {
            setLoading(false)
            setTimeout(() => setRefreshing(false), 500)
        }
    }, [token])

    // Initial fetch
    useEffect(() => {
        fetchTransactions()
    }, [fetchTransactions])

    // Notify parent component when selection changes
    useEffect(() => {
        if (onSelect) {
            const selectedTransactions: SelectedTransaction[] = selectedTransactionsSummary.selectedTransactions.map(
                (transaction) => ({
                    id: transaction.id,
                    amount: transaction.amount,
                    type: transaction.type,
                    description: transaction.description,
                    date: transaction.date,
                    provider: transaction.provider || "",
                    paymentMethod: getPaymentMethod(transaction.paymentMethod), // Convert to enum
                    reference: transaction.reference || "",
                }),
            )
            onSelect(selectedTransactions)
        }
    }, [selectedTransactionsSummary.selectedTransactions, onSelect])

    // Reset page when filters change
    useEffect(() => {
        setCurrentPage(1)
    }, [filters.searchTerm, filters.typeFilter, filters.providerFilter])

    // Filter handlers
    const handleSearchChange = (value: string) => {
        setFilters((prev) => ({ ...prev, searchTerm: value }))
        setCurrentPage(1)
    }

    const handleTypeFilterChange = (value: string) => {
        setFilters((prev) => ({ ...prev, typeFilter: value }))
        setCurrentPage(1)
    }

    const handleProviderFilterChange = (value: string) => {
        setFilters((prev) => ({ ...prev, providerFilter: value }))
        setCurrentPage(1)
    }

    const handleSort = (field: SortField) => {
        setFilters((prev) => ({
            ...prev,
            sortField: field,
            sortDirection: prev.sortField === field && prev.sortDirection === "asc" ? "desc" : "asc",
        }))
    }

    const resetFilters = () => {
        setFilters({
            searchTerm: "",
            typeFilter: "all",
            providerFilter: "all",
            sortField: null,
            sortDirection: "asc",
        })
        setCurrentPage(1)
    }

    // Selection handlers - now work with global selection
    const handleSelection = useCallback(
        (id: string, checked: boolean) => {
            if (checked) {
                // Get current transaction
                const currentTransaction = transactions.find((t) => t.id === id)

                // Check if already selected transactions have a different provider
                if (globalSelectedIds.size > 0 && currentTransaction) {
                    const firstSelectedTransaction = transactions.find((t) => globalSelectedIds.has(t.id))
                    if (firstSelectedTransaction && currentTransaction.provider !== firstSelectedTransaction.provider) {
                        setCurrentProviderName(formatProviderName(firstSelectedTransaction.provider))
                        setAttemptedProviderName(formatProviderName(currentTransaction.provider))
                        setShowProviderMismatchDialog(true)
                        return
                    }
                }

                // Add to global selection
                setGlobalSelectedIds((prev) => {
                    const newSet = new Set(prev)
                    newSet.add(id)
                    return newSet
                })
            } else {
                // Remove from global selection
                setGlobalSelectedIds((prev) => {
                    const newSet = new Set(prev)
                    newSet.delete(id)
                    return newSet
                })
            }
        },
        [transactions, globalSelectedIds],
    )

    const handleSelectAll = useCallback(
        (checked: boolean) => {
            if (checked) {
                // Select all transactions on current page
                setGlobalSelectedIds((prev) => {
                    const newSet = new Set(prev)
                    currentItems.forEach((transaction) => {
                        newSet.add(transaction.id)
                    })
                    return newSet
                })
            } else {
                // Deselect all transactions on current page
                setGlobalSelectedIds((prev) => {
                    const newSet = new Set(prev)
                    currentItems.forEach((transaction) => {
                        newSet.delete(transaction.id)
                    })
                    return newSet
                })
            }
        },
        [currentItems],
    )

    const handleSelectAllFiltered = useCallback(
        (checked: boolean) => {
            if (checked) {
                // Select all filtered transactions (across all pages)
                setGlobalSelectedIds((prev) => {
                    const newSet = new Set(prev)
                    filteredTransactions.forEach((transaction) => {
                        newSet.add(transaction.id)
                    })
                    return newSet
                })
            } else {
                // Deselect all filtered transactions
                setGlobalSelectedIds((prev) => {
                    const newSet = new Set(prev)
                    filteredTransactions.forEach((transaction) => {
                        newSet.delete(transaction.id)
                    })
                    return newSet
                })
            }
        },
        [filteredTransactions],
    )

    const clearAllSelections = useCallback(() => {
        setGlobalSelectedIds(new Set())
    }, [])

    // Pagination handler
    const handlePageChange = (page: number) => {
        setCurrentPage(page)
    }

    return {
        // Data
        transactions,
        filteredTransactions,
        currentItems,
        loading,
        refreshing,

        // Selection - now returns current page selection for UI, but maintains global selection
        selectedIds: currentPageSelectedIds,
        globalSelectedIds,
        selectedCount: selectedTransactionsSummary.count,
        selectedSummary: selectedTransactionsSummary,

        // Summary
        totalIncome,
        totalExpense,
        netAmount,

        // Filters
        filters,
        hasActiveFilters,

        // Pagination
        currentPage,
        totalPages,
        indexOfFirstItem,
        indexOfLastItem,
        totalItems: filteredTransactions.length,

        // Dialog
        showProviderMismatchDialog,
        currentProviderName,
        attemptedProviderName,

        // Actions
        fetchTransactions,
        handleSearchChange,
        handleTypeFilterChange,
        handleProviderFilterChange,
        handleSort,
        resetFilters,
        handleSelection,
        handleSelectAll,
        handleSelectAllFiltered,
        clearAllSelections,
        handlePageChange,
        setShowProviderMismatchDialog,
    }
}
