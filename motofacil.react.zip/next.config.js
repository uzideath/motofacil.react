module.exports = {
    'output': 'standalone',
}